using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Drawing;

namespace Entidades_2018
{
    public class Leche : Producto
    {
        #region Enumerados
        public enum ETipo
        {
          Entera,
          Descremada
        }
        #endregion

        #region Atributos
        ETipo tipo;
        #endregion

        #region Propiedades
        /// <summary>
        /// Las leches tienen 20 calorías
        /// </summary>
        protected override short CantidadCalorias
        {
            get
            {
                return 20;
            }
        }
        #endregion

        #region Constructores
        /// <summary>
        /// Por defecto, TIPO será ENTERA
        /// </summary>
        /// <param name="marca"></param>
        /// <param name="patente"></param>
        /// <param name="color"></param>
        public Leche(EMarca marca, string patente, ConsoleColor color)
            : base(patente, marca, color)
        {
            tipo = ETipo.Entera;
        }

        /// <summary>
        /// sobrecarga de constructor
        /// </summary>
        /// <param name="marca">marca de la leche</param>
        /// <param name="patente">patente de la leche </param>
        /// <param name="color">color primario de la leche</param>
        /// <param name="tipo">tipo de la leche</param>
        public Leche(EMarca marca, string patente, ConsoleColor color, ETipo tipo)
        :base(patente,marca,color)
        {
          this.tipo = tipo;
        }
        #endregion

        #region Metodos
        /// <summary>
        /// descripcion de la leche
        /// </summary>
        /// <returns></returns>
        public override string Mostrar()
        {
            StringBuilder Retorno;
            Retorno = new StringBuilder();

            Retorno.AppendLine(string.Format("LECHE"));
            Retorno.Append(base.Mostrar());
            Retorno.AppendLine(string.Format("CALORIAS : {0}", this.CantidadCalorias));
            Retorno.Append(string.Format("TIPO : {0}", this.tipo));
            Retorno.AppendLine("");
            Retorno.AppendLine("---------------------");

            return Retorno.ToString();
        }
        #endregion
    }
}
