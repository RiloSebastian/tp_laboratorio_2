using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades_2018
{
    public class Snacks: Producto
    {
        #region Propiedades
        /// <summary>
        /// Los snacks tienen 104 calorías
        /// </summary>
        protected override short CantidadCalorias
        {
            get
            {
                return 104;
            }
        }
        #endregion

        #region Constructores
        public Snacks(EMarca marca, string patente, ConsoleColor color)
            : base(patente, marca, color)
        {
        }
        #endregion
        
        #region Metodos
        public override string Mostrar()
        {
            StringBuilder Retorno;
            Retorno = new StringBuilder();

            Retorno.AppendLine(string.Format("SNACKS"));
            Retorno.AppendLine(base.Mostrar());
            Retorno.Append(string.Format("CALORIAS : {0}", this.CantidadCalorias));
            Retorno.AppendLine("");
            Retorno.AppendLine("---------------------");

            return Retorno.ToString();
        }
        #endregion
    }
}
