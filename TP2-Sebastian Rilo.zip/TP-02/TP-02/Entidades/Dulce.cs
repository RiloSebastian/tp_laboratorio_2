using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades_2018
{
    public class Dulce : Producto
    {   
        #region Propiedades
        /// <summary>
        /// Los dulces tienen 80 calorías
        /// </summary>
        protected override short CantidadCalorias
        {
            get
            {
                return 80;
            }
        }
        #endregion

        #region Constructores
        /// <summary>
        /// constructor del dulce
        /// </summary>
        /// <param name="marca">marca del dulce</param>
        /// <param name="patente">patente del dulce</param>
        /// <param name="color">color de dulce</param>
        public Dulce(EMarca marca, string patente, ConsoleColor color):base(patente,marca,color)
        {
        }
        #endregion

        #region Metodos
        /// <summary>
        /// descripcion del dulce
        /// </summary>
        /// <returns></returns>
        public override string Mostrar()
        {
            StringBuilder Retorno;
            Retorno = new StringBuilder();
            Retorno.AppendLine(string.Format("DULCE"));
            Retorno.AppendLine(base.Mostrar());
            Retorno.Append(string.Format("CALORIAS : {0}", this.CantidadCalorias));
            Retorno.AppendLine("");
            Retorno.AppendLine("---------------------");

            return Retorno.ToString();
        }
        #endregion
    }
}
