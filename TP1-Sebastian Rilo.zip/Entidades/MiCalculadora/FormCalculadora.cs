﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace MiCalculadora
{
    public partial class FormCalculadora : Form
    {
        #region Constructor

        /// <summary>
        /// inicializa los componentes de la calculadora.
        /// </summary>
        public FormCalculadora()
        {
            InitializeComponent();
        }
        #endregion

        #region Metodos

        /// <summary>
        /// al hacer click en el boton "Operar" se realiza una operacion con los contenidos de txtNumero1, txtNumero2 y cmbOperador.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOperar_Click(object sender, EventArgs e)
        {
            
            lblResultado.Text = FormCalculadora.Operar(txtNumero1.Text, txtNumero2.Text, cmbOperador.Text);
            if(cmbOperador.Text == "")
            {
                cmbOperador.Text = "+";
            }
            if(txtNumero1.Text=="")
            {
                txtNumero1.Text = "0";
            }
            if(txtNumero2.Text=="")
            {
                txtNumero2.Text = "0";
            }
            if (btnConvertirABinario.Enabled == false || btnConvertirADecimal.Enabled == false)
            {
                btnConvertirABinario.Enabled = true;
                btnConvertirADecimal.Enabled = true;
            }
        }

        /// <summary>
        /// al hacer click en el boton "Limpiar" se borran los contenidos de "txtNumero1", "txtNumero2" y "cmbOperador".
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNumero1.Text = "";
            txtNumero2.Text = "";
            cmbOperador.Text = "";
            lblResultado.Text = "";
            if (btnConvertirABinario.Enabled == false || btnConvertirADecimal.Enabled == false)
            {
                btnConvertirABinario.Enabled = true;
                btnConvertirADecimal.Enabled = true;
            }
        }

        /// <summary>
        /// al hacer click en el boton "Cerrar" se cierra el formulario.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// al hacer click en el boton "Convertir a Binario" se realiza una conversion del resultado de una operacion a su equivalente binario.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnConvertirABinario_Click(object sender, EventArgs e)
        {
            if(lblResultado.Text != "")
            {
                lblResultado.Text = Numero.DecimalBinario(lblResultado.Text);
                btnConvertirABinario.Enabled = false;
                btnConvertirADecimal.Enabled = true;
            }
        }

        /// <summary>
        /// al hacer click en el boton "Convertir a Decimal" se realiza una conversion del resultado de una operacion a su equivalente decimal.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnConvertirADecimal_Click(object sender, EventArgs e)
        {
            if (lblResultado.Text != "")
            {
                lblResultado.Text=Numero.BinarioDecimal(lblResultado.Text);
                btnConvertirADecimal.Enabled = false;
                btnConvertirABinario.Enabled = true;
            }
        }

        /// <summary>
        /// se recibe el contenido de "txtNumero1", "txtNumero2" y "cmbOperador" y se los usa como parametros para el metodo "Calculadora.Operar".
        /// </summary>
        /// <param name="Numero1"></param>
        /// <param name="Numero2"></param>
        /// <param name="Operador"></param>
        /// <returns></returns>
        private static string Operar(string Numero1, string Numero2, string Operador)
        {
            Numero numeroUno = new Numero(Numero1);
            Numero numeroDos = new Numero(Numero2);
            double Resultado = Calculadora.Operar(numeroUno, numeroDos, Operador);
            return Resultado.ToString();
        }
        #endregion
    }
}
