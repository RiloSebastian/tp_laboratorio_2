﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class Calculadora
    {
        #region Metodos
        /// <summary>
        /// realiza un tipo de operacion aritmetica entre dos numeros segun el operador
        /// </summary>
        /// <param name="Num1"></param>
        /// <param name="num2"></param>
        /// <param name="operador"></param>
        /// <returns></returns>
        public static double Operar(Numero Num1, Numero num2, string operador)
        {
            double Resultado = 0;

            switch (char.Parse(Calculadora.ValidarOperador(operador)))
            {
                case '+':
                    Resultado = Num1 + num2;
                    break;
                case '-':
                    Resultado = Num1 - num2;
                    break;
                case '*':
                    Resultado = Num1 * num2;
                    break;
                case '/':
                    try
                    {
                        Resultado = Num1 / num2;
                    }
                    catch (DivideByZeroException)
                    {
                        Resultado = double.MinValue;
                    }
                    break;
                default:
                    break;
            }
            return Resultado;
        }

        /// <summary>
        /// valida que el operador que va a recibir el metodo operar sea correcto. de lo contrario devuelve '+'
        /// </summary>
        /// <param name="Operador"></param>
        /// <returns></returns>
        private static string ValidarOperador(string Operador)
        {
            string Retorno = "+";
            char AuxiliarOperador;
            if (char.TryParse(Operador, out AuxiliarOperador))
            {
                switch (AuxiliarOperador)
                {
                    case '-':
                        Retorno = "-";
                        break;
                    case '*':
                        Retorno = "*";
                        break;
                    case '/':
                        Retorno = "/";
                        break;
                    default:
                        break;
                }
            }
            return Retorno;
        }
        #endregion
    }
}
