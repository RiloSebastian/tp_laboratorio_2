﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Numero
    {
        #region atributos
        private double Num;
        #endregion

        #region Propiedades
        /// <summary>
        /// asigna un valor al atributo Numero.
        /// </summary>
        public string SetNumero
        {
            set => Num = ValidarNumero(value);
        }
        #endregion

        #region Constructores

        /// <summary>
        /// constructor que recibe un double y lo asigna como valor de un numero.
        /// </summary>
        /// <param name="numero"></param>
        public Numero(double numero)
        {
            this.Num = numero;
        }

        /// <summary>
        /// constructor que no recibe nada y asigna '0' como valor de un numero.
        /// </summary>
        public Numero() : this(0)
        {
        }

        /// <summary>
        /// constructor que recibe un string y lo asigna como valor de un numero.
        /// </summary>
        /// <param name="StrNumero"></param>
        public Numero(string StrNumero)
        {
            this.SetNumero = StrNumero;
        }
        #endregion

        #region Metodos

        /// <summary>
        /// sobrecarga de operador '+' para dos objetos de tipo "Numero".
        /// </summary>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <returns></returns>
        public static double operator +(Numero n1, Numero n2)
        {
            double Retorno = 0;
            Retorno = n1.Num + n2.Num;
            return Retorno;
        }

        /// <summary>
        /// sobrecarga de operador '-' para dos objetos de tipo "Numero".
        /// </summary>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <returns></returns>
        public static double operator -(Numero n1, Numero n2)
        {
            double Retorno = -1;
            Retorno = n1.Num - n2.Num;
            return Retorno;
        }

        /// <summary>
        /// sobrecarga de operador '*' para dos objetos de tipo "Numero".
        /// </summary>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <returns></returns>
        public static double operator *(Numero n1, Numero n2)
        {
            double Retorno = -1;
            Retorno = n1.Num * n2.Num;
            return Retorno;
        }

        /// <summary>
        /// sobrecarga de operador '/' para dos objetos de tipo "Numero".
        /// </summary>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <returns></returns>
        public static double operator /(Numero n1, Numero n2)
        {
            double Retorno = -1;
            Retorno = n1.Num / n2.Num;
            return Retorno;
        }

        /// <summary>
        /// valida que el numero recibido sea un numero valido.
        /// </summary>
        /// <param name="StrNumero"></param>
        /// <returns></returns>
        private static double ValidarNumero(string StrNumero)
        {
            double Retorno = 0;
            if (double.TryParse(StrNumero, out Retorno))
            {
                return Retorno;
            }
            return Retorno;
        }

        /// <summary>
        /// transforma un numero binario en su equivalente decimal.
        /// </summary>
        /// <param name="Binario"></param>
        /// <returns></returns>
        public static string BinarioDecimal(string Binario)
        {
            string Retorno = "Valor Invalido";
            char[] Numero = Binario.ToCharArray();
            Array.Reverse(Numero);
            int NumeroConvertido = 0;
            double Auxiliar;

            if (double.TryParse(Binario, out Auxiliar) && Auxiliar > 0 && Auxiliar%1 ==0)
            {
                for (int i = 0; i < Numero.Length; i++)
                {
                    if (Numero[i] == '1' || Numero[i] == '0')
                    {
                        if (Numero[i] == '1')
                        {
                            NumeroConvertido += (int)Math.Pow(2, i);
                        }
                    }
                    else
                    {
                        return "Valor Invalido";
                    }
                }
                Retorno = NumeroConvertido.ToString();
            }
            return Retorno;
        }

        /// <summary>
        /// transforma un numero binario en su equivalente decimal.
        /// </summary>
        /// <param name="Decimal"></param>
        /// <returns></returns>
        public static string DecimalBinario(double Decimal)
        {
            string Retorno = "Valor Invalido";

            if (!double.IsNaN(Decimal))
            {
                int numero = Convert.ToInt32(Decimal);
                if (numero > 0 && numero % 1 == 0)
                {
                    String cadena = "";
                    while (numero > 0)
                    {
                        if (numero % 2 == 0)
                        {
                            cadena = "0" + cadena;
                        }
                        else
                        {
                            cadena = "1" + cadena;
                        }
                        numero = (int)(numero / 2);
                    }
                    Retorno = string.Copy(cadena);
                }
            }
            return Retorno;
        }

        /// <summary>
        /// transforma un decimal en su equivalente binario.
        /// </summary>
        /// <param name="Decimal"></param>
        /// <returns></returns>
        public static string DecimalBinario(string Decimal)
        {
            double Auxiliar;
            if (double.TryParse(Decimal, out Auxiliar))
            {
                return Numero.DecimalBinario(Auxiliar);
            }
            return "Valor Invalido";
        }
        #endregion
    }
}
