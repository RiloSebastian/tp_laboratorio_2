﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    public class AlumnoRepetidoException: Exception
    {
        /// <summary>
        /// se repite un alumno en la lista
        /// </summary>
        public AlumnoRepetidoException() : base("error. este alumno ya esta en la lista")
        { }
    }
}
