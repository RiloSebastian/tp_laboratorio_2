﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    public class NacionalidadInvalidaException: Exception
    {
        /// <summary>
        /// la nacionalidad del individuo es invalida
        /// </summary>
        public NacionalidadInvalidaException():base("nacionalidad invalida")
        { }

        /// <summary>
        /// la nacionalida del individuo es unvalida. recibe mensaje
        /// </summary>
        /// <param name="message">mensaje</param>
        public NacionalidadInvalidaException(string message) : base(message)
        { }
    }
}
