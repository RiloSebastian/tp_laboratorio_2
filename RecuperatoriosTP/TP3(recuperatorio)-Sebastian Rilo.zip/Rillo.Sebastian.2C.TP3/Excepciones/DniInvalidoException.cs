﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    public class DniInvalidoException: Exception
    {
        /// <summary>
        /// el dni no es valido
        /// </summary>
        public DniInvalidoException():base("dni invalido")
        { }

        /// <summary>
        /// el dni es invalido. recibe una excepcion
        /// </summary>
        /// <param name="e">excepcion</param>
        public DniInvalidoException(Exception e) : base(e.Message)
        { }

        /// <summary>
        /// el dni no es valido. recibe un mensaje
        /// </summary>
        /// <param name="message"></param>
        public DniInvalidoException(string message) : base(message)
        { }

        /// <summary>
        /// el dni no es valido. recibe un mensaje y una innerEsxception
        /// </summary>
        /// <param name="message"></param>
        /// <param name="e"></param>
        public DniInvalidoException(string message, Exception e) : base(message,e)
        { }
    }
}
