﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    public class ArchivosException : Exception
    {
        /// <summary>
        /// excepcion relacionada al manejo de archivos
        /// </summary>
        /// <param name="e">excepcion</param>
        public ArchivosException(Exception e) : base(e.Message)
        { }
    }
}
