﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadesAbstractas
{
    public abstract class Universitario : Persona
    {
        private int legajo;

        /// <summary>
        /// constructor por defecto
        /// </summary>
        public Universitario()
        { }

        /// <summary>
        /// constructor de instancia
        /// </summary>
        /// <param name="legajo">legajo del nuevo universitario</param>
        /// <param name="nombre">nombre del nuevo universitario</param>
        /// <param name="apellido">apellido del nuevo universitario</param>
        /// <param name="dni">dni del nuevo universitario</param>
        /// <param name="nacionalidad">nacionalidad del nuevo universitario</param>
        public Universitario(int legajo, string nombre, string apellido, string dni, ENacionalidad nacionalidad)
            : base(nombre,apellido,dni,nacionalidad)
        {
            this.legajo = legajo;
        }

        /// <summary>
        /// compara 2 universitarios para saber si son el mismo
        /// </summary>
        /// <param name="pg1">el primer universitario</param>
        /// <param name="pg2">el segundo universitario</param>
        /// <returns></returns>
        public static bool operator ==(Universitario pg1, Universitario pg2)
        {
            if(pg1.Equals(pg2) && (pg1.DNI == pg2.DNI || pg1.legajo == pg2.legajo))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// compara 2 universitarios para saber si son distintos
        /// </summary>
        /// <param name="pg1">el primer universitario</param>
        /// <param name="pg2">el segundo universitario</param>
        /// <returns></returns>
        public static bool operator !=(Universitario pg1, Universitario pg2)
        {
            return !(pg1==pg2);
        }

        /// <summary>
        /// devuelve true si obj es universitario
        /// </summary>
        /// <param name="obj">el objeto</param>
        /// <returns></returns>
        public override bool Equals(object obj)
        {
            if(obj is Universitario)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// muestra todos los datos del universitario
        /// </summary>
        /// <returns></returns>
        protected virtual string MostrarDatos()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append(base.ToString());
            retorno.AppendLine(string.Format("legajo:{0}", this.legajo));
            return retorno.ToString();
        }

        /// <summary>
        /// firma del metodo
        /// </summary>
        /// <returns></returns>
        protected abstract string ParticiparEnClase();
    }
}
