﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Excepciones;

namespace EntidadesAbstractas
{
    

    public abstract class Persona
    {
        public enum ENacionalidad
        {
            Argentino,
            Extranjero
        }
        private int dni;
        private string nombre;
        private string apellido;
        private ENacionalidad nacionalidad;

        public int DNI
        {
            get
            {
                return dni;
            }
            set
            {
                dni = ValidarDni(Nacionalidad, value);
            }
        }

        public string Nombre
        {
            get
            {
                return nombre;
            }
            set
            {
                nombre = ValidarNombreApellido(value);
            }
        }


        public string Apellido
        {
            get
            {
                return apellido;
            }
            set
            {
                apellido = ValidarNombreApellido(value);
            }
        }


        public ENacionalidad Nacionalidad
        {
            get
            {
                return nacionalidad;
            }
            set
            {
                nacionalidad = value;
            }
        }

        public string StringToDNI
        {
            set
            {
                dni = ValidarDni(Nacionalidad, value);
            }
        }

        /// <summary>
        /// constructor por defecto
        /// </summary>
        public Persona()
        {

        }

        /// <summary>
        /// constructor de instancia.
        /// </summary>
        /// <param name="nombre">el nombre de la persona</param>
        /// <param name="apellido">el apellido de la persona</param>
        /// <param name="nacionalidad">la nacionalidad de la persona</param>
        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
        {
            Nombre = nombre;
            Apellido = apellido;
            Nacionalidad = nacionalidad;
        }

        /// <summary>
        /// sobrecarga de constructor. agrega dni(entero)
        /// </summary>
        /// <param name="nombre">el nombre de la persona</param>
        /// <param name="apellido">el apellido de la persona</param>
        /// <param name="dni">el dni de la persona</param>
        /// <param name="nacionalidad">la nacionalidad de la persona</param>
        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad):this(nombre,apellido,dni.ToString(),nacionalidad)
        { }

        /// <summary>
        /// sobrecarga de constructor. agrega dni(string)
        /// </summary>
        /// <param name="nombre">el nombre de la persona</param>
        /// <param name="apellido">el apellido de la persona</param>
        /// <param name="dni">el dni de la persona</param>
        /// <param name="nacionalidad">la nacionalidad de la persona</param>
        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad):this(nombre,apellido,nacionalidad)
        {
            StringToDNI = dni;
        }

        /// <summary>
        /// muestra los datos de la persona
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendLine(string.Format("Dni:{0}",DNI));
            retorno.AppendLine(string.Format("Nombre:{0}", Nombre));
            retorno.AppendLine(string.Format("Apellido:{0}", Apellido));
            retorno.AppendLine(string.Format("Nacionalidad:{0}", Nacionalidad));

            return retorno.ToString();
        }

        /// <summary>
        /// valida que el dni sea correcto y corresponda con la nacionalidad
        /// </summary>
        /// <param name="nacionalidad"></param>
        /// <param name="dato"></param>
        /// <returns></returns>
        private int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
            return ValidarDni(nacionalidad, dato.ToString());
        }

        /// <summary>
        /// valida que el dni sea correcto y corresponda con la nacionalidad
        /// </summary>
        /// <param name="nacionalidad"></param>
        /// <param name="dato"></param>
        /// <returns></returns>
        private int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            int auxiliar=0;
                try
                {
                    auxiliar = int.Parse(dato);
                    if ((nacionalidad == ENacionalidad.Argentino && auxiliar >= 1 && auxiliar <= 89999999) ||
                    (nacionalidad == ENacionalidad.Extranjero && auxiliar >= 90000000 && auxiliar <= 99999999))
                    {
                        return auxiliar;
                    }
                    else
                    {
                        throw new NacionalidadInvalidaException("el dni esta fuera de los parametros estipulados");
                    }

                }
                catch(FormatException e)
                {
                    throw new DniInvalidoException(e);
                }
        }

        /// <summary>
        /// valida que el nombre sea correcto
        /// </summary>
        /// <param name="dato"></param>
        /// <returns></returns>
        private string ValidarNombreApellido(string dato)
        {
            Match match = Regex.Match(dato, "^[a-zA-ZÁÉÍÓÚáéíóú ]*$");
            if (match.Success)
            {
                return dato;
            }
            return "";
        }
    }
}
