﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Archivos
{
    public interface IArchivo<T>
    {
        /// <summary>
        /// firma de metodo generico para guardar datos en un archivo
        /// </summary>
        /// <param name="archivo">el archivo a escribir</param>
        /// <param name="dato">el dato a escribir</param>
        /// <returns></returns>
        bool Guardar(string archivo, T dato);

        /// <summary>
        /// firma de metodo generico para leer datos en un archivo
        /// </summary>
        /// <param name="archivo">el archivo a leer</param>
        /// <param name="dato"> el dato a leer</param>
        /// <returns></returns>
        bool Leer(string archivo, out T dato);
    }
}
