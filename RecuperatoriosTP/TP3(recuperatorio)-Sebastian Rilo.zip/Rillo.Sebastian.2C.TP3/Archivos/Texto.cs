﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using Excepciones;

namespace Archivos
{
    public class Texto : IArchivo<string>
    {
        /// <summary>
        /// guarda un dato en un archivo de texto
        /// </summary>
        /// <param name="archivo">el archivo a escribir</param>
        /// <param name="dato">el dato a escribir</param>
        /// <returns></returns>
        public bool Guardar(string archivo, string dato)
        {
            StreamWriter writer = new StreamWriter(archivo,false);
            try
            {
                writer.WriteLine(dato);
                return true;
            }
            catch(Exception e)
            {
                throw new ArchivosException(e);
            }
            finally
            {
                writer.Close();
            }

        }

        /// <summary>
        /// lee datos de un archivo de texto
        /// </summary>
        /// <param name="archivo">el archivo de texto</param>
        /// <param name="dato">el dato a leer</param>
        /// <returns></returns>
        public bool Leer(string archivo, out string dato)
        { 
                StreamReader reader = new StreamReader(archivo,Encoding.UTF8);

                try
                {
                    dato = reader.ReadToEnd();
                    return true;
                }
                catch(Exception e)
                {
                    throw new ArchivosException(e);
                }
                finally
                {
                    reader.Close();
                }
        }
    }
}
