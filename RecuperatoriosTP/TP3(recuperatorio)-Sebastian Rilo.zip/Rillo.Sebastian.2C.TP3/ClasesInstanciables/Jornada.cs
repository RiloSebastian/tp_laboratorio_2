﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Archivos;
using Excepciones;

namespace ClasesInstanciables
{
    public class Jornada: Texto
    {
        static List<Alumno> alumnos;
        private Universidad.EClases clase;
        private Profesor instructor;

        public List<Alumno> Alumnos
        {
            get
            {
                return alumnos;
            }
            set
            {
                alumnos = value;
            }
        }

        public Profesor Instructor
        {
            get
            {
                return instructor;
            }
            set
            {
                instructor = value;
            }
        }

        public Universidad.EClases Clase
        {
            get
            {
                return clase;
            }
            set
            {
                clase = value;
            }
        }

        /// <summary>
        /// constructor por defecto de jornada
        /// </summary>
        private Jornada()
        {
            
        }

        /// <summary>
        /// constructor de instancia de jornada. inicializa la lista de alumnos
        /// </summary>
        /// <param name="clase">la clase de la jornada</param>
        /// <param name="instructor">el profesor de la jornada</param>
        public Jornada(Universidad.EClases clase, Profesor instructor)
        {
            alumnos = new List<Alumno>();
            Clase = clase;
            Instructor = instructor;
        }

        /// <summary>
        /// indica si el alumno se repite
        /// </summary>
        /// <param name="j">la jornada</param>
        /// <param name="a">el alumno</param>
        /// <returns></returns>
        public static bool operator ==(Jornada j, Alumno a)
        {
            foreach(Alumno enLaClase in j.Alumnos)
            {
                if ((a == enLaClase))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// indica si el alumno no se repite
        /// </summary>
        /// <param name="j">la jornada</param>
        /// <param name="a">el alumno</param>
        /// <returns></returns>
        public static bool operator !=(Jornada j, Alumno a)
        {
            return !(j == a);
        }

        /// <summary>
        /// agrega un alumno a la jornada
        /// </summary>
        /// <param name="j">la jornada</param>
        /// <param name="a">el alumno</param>
        /// <returns></returns>
        public static Jornada operator +(Jornada j, Alumno a)
        {
            if (!(j == a))
            {
                j.Alumnos.Add(a);
            }
            return j;
        }

        /// <summary>
        /// guarda los datos de la jornada en un archivo de texto
        /// </summary>
        /// <param name="jornada">la jornada</param>
        /// <returns></returns>
        public static bool Guardar(Jornada jornada)
        {
            return new Texto().Guardar((Environment.GetFolderPath(Environment.SpecialFolder.Desktop)) + @"\Jornada.txt", jornada.ToString());
        }

        /// <summary>
        /// lee los datos de una jornada de un archivo de texto
        /// </summary>
        /// <returns></returns>
        public string Leer()
        {
            string jornadaTexto;
            new Texto().Leer((Environment.GetFolderPath(Environment.SpecialFolder.Desktop)) + @"\Jornada.txt", out jornadaTexto);
            return jornadaTexto;
        }

        /// <summary>
        /// muestra los datos de una jornada
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendLine(string.Format("CLASE:{0}", Clase));
            retorno.Append(string.Format("INSTRUCTOR:\n{0}\n", Instructor.ToString()));
            retorno.AppendLine("ALUMNOS:\n");
            retorno.Append("---------------------------------");
            foreach(Alumno a in Alumnos)
            {
                retorno.Append(string.Format("\n{0}\n", a.ToString()));
                retorno.AppendLine("---------------------------------");
            }
            return retorno.ToString();
        }
    }
}
