﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
using EntidadesAbstractas;

namespace ClasesInstanciables
{
    
    public sealed class Alumno: Universitario
    {
        public enum EEstadoCuenta
        {
            AlDia,
            Deudor,
            Becado
        }

        private Universidad.EClases clasesQueToma;
        private EEstadoCuenta estadoCuenta;

        /// <summary>
        /// constructor por defecto de alumno
        /// </summary>
        public Alumno()
        { }

        /// <summary>
        /// constructor de instancia de alumno
        /// </summary>
        /// <param name="id">id del alumno</param>
        /// <param name="nombre">nombre del alumno</param>
        /// <param name="apellido">apellido del alumno</param>
        /// <param name="dni">dni del alumno</param>
        /// <param name="nacionalidad">nacionalidad del alumno</param>
        /// <param name="clase">clase que cursa el alumno</param>
        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases clase)
            :base(id,nombre,apellido,dni,nacionalidad)
        {
            this.clasesQueToma = clase;
        }

        /// <summary>
        /// sobrecarga de constructor de instancia de alumno. agrega el estado de cuenta
        /// </summary>
        /// <param name="id">id del alumno</param>
        /// <param name="nombre">nombre del alumno</param>
        /// <param name="apellido">apellido del alumno</param>
        /// <param name="dni">dni del alumno</param>
        /// <param name="nacionalidad">nacionalidad del alumno</param>
        /// <param name="clase">clase que cursa el alumno</param>
        /// <param name="estadoDeCuenta">estado de cuenta del alumno</param>
        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases clase, EEstadoCuenta estadoDeCuenta)
            :this(id,nombre,apellido,dni,nacionalidad,clase)
        {
            this.estadoCuenta = estadoDeCuenta;
        }

        /// <summary>
        /// indica si el alumno toma una clase en particular
        /// </summary>
        /// <param name="a">el alumno</param>
        /// <param name="clases">la clase</param>
        /// <returns></returns>
        public static bool operator ==(Alumno a, Universidad.EClases clases)
        {
            if(a.clasesQueToma== clases && a.estadoCuenta != EEstadoCuenta.Deudor)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// indica si el alumno no toma una clase en particular
        /// </summary>
        /// <param name="a">el alumno</param>
        /// <param name="clases">la clase</param>
        /// <returns></returns>
        public static bool operator !=(Alumno a, Universidad.EClases clases)
        {
            return !(a == clases);
        }

        /// <summary>
        /// muestra los datos del alumno
        /// </summary>
        /// <returns></returns>
        protected override string MostrarDatos()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append(base.MostrarDatos());
            retorno.AppendLine(string.Format("clase que toma:{0}", this.clasesQueToma));
            retorno.AppendLine(string.Format("estado de cuenta:{0}", this.estadoCuenta));
            return retorno.ToString();
        }

        /// <summary>
        /// muestra la clase en que el alumno participa
        /// </summary>
        /// <returns></returns>
        protected override string ParticiparEnClase()
        {
            return string.Format("TOMA CLASE DE:{0}", clasesQueToma);
        }

        public override string ToString()
        {
            return this.MostrarDatos();
        }
    }
}
