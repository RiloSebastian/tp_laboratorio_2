﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesAbstractas;

namespace ClasesInstanciables
{
    public sealed class Profesor: Universitario
    {
        private Queue<Universidad.EClases> clasesDelDia;
        static Random random;

        /// <summary>
        /// constructor por defecto de profesor
        /// </summary>
        public Profesor()
        { }

        /// <summary>
        /// instancia la variable ramdom
        /// </summary>
        static Profesor()
        {
            
            random = new Random();
        }

        /// <summary>
        /// constructor de instancia de profesor
        /// </summary>
        /// <param name="id">id del profesor</param>
        /// <param name="nombre">nombre del profesor</param>
        /// <param name="apellido">apellido el profesor</param>
        /// <param name="dni">dni del profesor</param>
        /// <param name="nacionalidad">nacionalidad del profesor</param>
        public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad): base(id,nombre,apellido,dni,nacionalidad)
        {
            clasesDelDia = new Queue<Universidad.EClases>();
            _ramdomClases();
        }

        /// <summary>
        /// indica si si un profesor da una clase especifica
        /// </summary>
        /// <param name="i">el profesor</param>
        /// <param name="clases">la clase</param>
        /// <returns></returns>
        public static bool operator ==(Profesor i, Universidad.EClases clases)
        {
            foreach(Universidad.EClases claseQueDa in i.clasesDelDia)
            {
                if(claseQueDa == clases)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// indica si si un profesor da una clase especifica
        /// </summary>
        /// <param name="i">el profesor</param>
        /// <param name="clases">la clase</param>
        /// <returns></returns>
        public static bool operator !=(Profesor i, Universidad.EClases clases)
        {
            return !(i == clases);
        }

        /// <summary>
        /// agrega dos clases aleatorioas a las clases que da el profesor
        /// </summary>
        private void _ramdomClases()
        {
            for(int i = 0; i < 2; i++)
            {
                clasesDelDia.Enqueue((Universidad.EClases)random.Next(0, 4));
            }  
        }

        /// <summary>
        /// muestra los datos del profesor
        /// </summary>
        /// <returns></returns>
        protected override string MostrarDatos()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append(base.MostrarDatos());
            retorno.Append(ParticiparEnClase());
            return retorno.ToString();
        }

        /// <summary>
        /// muestra las clases del dia del profesor
        /// </summary>
        /// <returns></returns>
        protected override string ParticiparEnClase()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.AppendLine("CLASES DEL DIA:");
            foreach (Universidad.EClases clase in clasesDelDia)
            {
                retorno.AppendLine(string.Format("{0}", clase));
            }

            return retorno.ToString();
        }

        /// <summary>
        /// reutilizacoin de MostrarDatos
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return MostrarDatos();
        }
    }
}
