﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
using Archivos;

namespace ClasesInstanciables
{
    
    public class Universidad: Xml<Universidad>
    {
        public enum EClases
        {
            Programacion,
            Laboratorio,
            Legislacion,
            SPD
        }
        private List<Alumno> alumnos;
        private List<Jornada> jornadas;
        private List<Profesor> profesores;

        public List<Alumno> Alumnos
        {
            get
            {
                return alumnos;
            }
            set
            {
                alumnos = value;
            }
        }

        public List<Profesor> Profesores
        {
            get
            {
                return profesores;
            }
            set
            {
                profesores = value;
            }
        }

        public List<Jornada> Jornadas
        {
            get
            {
                return jornadas;
            }
            set
            {
                jornadas = value;
            }
        }

        public Jornada this[int i]
        {
            get
            {
                return jornadas[i];
            }
            set
            {
                jornadas[i] = value;
            }
        }

        /// <summary>
        /// inicializa las listas de la universidad
        /// </summary>
        public Universidad()
        {
            Profesores = new List<Profesor>();
            Alumnos = new List<Alumno>();
            Jornadas = new List<Jornada>();
        }

        /// <summary>
        /// indica si un alumno esta en la universidad
        /// </summary>
        /// <param name="u">la universidad</param>
        /// <param name="a">el alumno</param>
        /// <returns></returns>
        public static bool operator ==(Universidad u, Alumno a)
        {
            foreach(Alumno alumnoAnotado in u.Alumnos)
            {
                if(alumnoAnotado == a)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// indica si un profesor esta en la universidad
        /// </summary>
        /// <param name="u"></param>
        /// <param name="p"></param>
        /// <returns></returns>
        public static bool operator ==(Universidad u, Profesor p)
        {
            foreach (Profesor profesorAnotado in u.Profesores)
            {
                if (profesorAnotado == p)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// indica si hay algun profesor que pueda dar una clase en particular
        /// </summary>
        /// <param name="u">la universidad</param>
        /// <param name="clase">la clase</param>
        /// <returns></returns>
        public static Profesor operator ==(Universidad u, EClases clase)
        {
            foreach(Profesor profesorAnotado in u.Profesores)
            {
                if(profesorAnotado == clase)
                {
                    return profesorAnotado;
                }
            }
            throw new SinProfesorException();
        }

        /// <summary>
        /// indica si un alumno no esta en la universidad
        /// </summary>
        /// <param name="u">la universidad</param>
        /// <param name="a">el alumno</param>
        /// <returns></returns>
        public static bool operator !=(Universidad u, Alumno a)
        {
            return !(u == a);
        }

        /// <summary>
        /// indica si un profesor no esta en la universidad
        /// </summary>
        /// <param name="u">la universidad</param>
        /// <param name="p">el profesor</param>
        /// <returns></returns>
        public static bool operator !=(Universidad u, Profesor p)
        {
            return !(u == p);
        }

        /// <summary>
        /// indica si hay algun profesor que pueda dar una clase en particular
        /// </summary>
        /// <param name="u">la universidad</param>
        /// <param name="clase">la clase</param>
        /// <returns></returns>
        public static Profesor operator !=(Universidad u, EClases clase)
        {
            Profesor primeroNoHabilitado= new Profesor();

            foreach (Profesor profesorAnotado in u.Profesores)
            {
                if (profesorAnotado != clase)
                {
                   primeroNoHabilitado= profesorAnotado;
                    break;
                }
            }
            return primeroNoHabilitado;
        }

        /// <summary>
        /// agrega una nueva jornada a la universidad con un profesor disponible para darla y alumnos que cursen esa clase
        /// </summary>
        /// <param name="u">la universidad</param>
        /// <param name="clase">la clase a cursar</param>
        /// <returns></returns>
        public static Universidad operator +(Universidad u, EClases clase)
        {
            Jornada nuevaJornada= new Jornada(clase,(u==clase));
            foreach(Alumno a in u.Alumnos)
            {
                if (a == clase)
                {
                    nuevaJornada.Alumnos.Add(a);
                }
            }
            u.Jornadas.Add(nuevaJornada);
            return u;
        }

        /// <summary>
        /// agrega un alumno a la universidad
        /// </summary>
        /// <param name="u">la universidad</param>
        /// <param name="a">el alumno</param>
        /// <returns></returns>
        public static Universidad operator +(Universidad u, Alumno a)
        {
            if (u != a)
            {
                u.Alumnos.Add(a);
            }
            else
            {
                throw new AlumnoRepetidoException();
            }
            return u;
        }

        /// <summary>
        /// agrega un profesor a la universidad
        /// </summary>
        /// <param name="u">la universidad</param>
        /// <param name="p"></param>
        /// <returns>el profesor</returns>
        public static Universidad operator +(Universidad u, Profesor p)
        {
            if (u != p)
            {
                u.Profesores.Add(p);
            }
            return u;
        }

        /// <summary>
        /// guarda los datos de la universidad en un archivo xml
        /// </summary>
        /// <param name="uni">la universidad</param>
        /// <returns></returns>
        public static bool Guardar(Universidad uni)
        {
            return new Xml<Universidad>().Guardar((Environment.GetFolderPath(Environment.SpecialFolder.Desktop)) + @"\Universidad.xml", uni);
        }

        /// <summary>
        /// lee los datos de una universidad de un archivo xml
        /// </summary>
        /// <returns></returns>
        public Universidad Leer()
        {
            Universidad uni = new Universidad();
            new Xml<Universidad>().Leer((Environment.GetFolderPath(Environment.SpecialFolder.Desktop)) + @"\Universidad.xml", out uni);
            return uni;
        }

        /// <summary>
        /// muestra los datos de la universidad
        /// </summary>
        /// <param name="uni">la universidad</param>
        /// <returns></returns>
        private string MostrarDatos(Universidad uni)
        {
            return uni.ToString();
        }

        /// <summary>
        /// reutiliza MostrarDatos
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();

            retorno.AppendLine("UNIVERSIDAD");
            retorno.AppendLine("JORNADAS:\n");
            retorno.Append("---------------------------------");
            foreach (Jornada j in Jornadas)
            {
                retorno.Append(string.Format("\n{0}\n", j.ToString()));
                retorno.AppendLine("---------------------------------");
            }
            retorno.AppendLine("PROFESORES:\n");
            retorno.Append("---------------------------------");
            foreach (Profesor p in Profesores)
            {
                retorno.Append(string.Format("\n{0}\n", p.ToString()));
                retorno.AppendLine("---------------------------------");
            }
            retorno.AppendLine("ALUMNOS:\n");
            retorno.Append("---------------------------------");
            foreach (Alumno a in Alumnos)
            {
                retorno.Append(string.Format("\n{0}\n", a.ToString()));
                retorno.AppendLine("---------------------------------");
            }
            return retorno.ToString();
        }
    }
}
