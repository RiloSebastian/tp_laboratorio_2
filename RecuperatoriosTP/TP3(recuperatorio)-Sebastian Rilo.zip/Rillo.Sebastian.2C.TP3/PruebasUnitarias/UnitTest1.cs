﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EntidadesAbstractas;
using ClasesInstanciables;
using Excepciones;

namespace PruebasUnitarias
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        [ExpectedException(typeof(NacionalidadInvalidaException))]
        public void NacionalidadInvalidoExcepcionPrueba()
        {
            Alumno alumno;
            alumno = new Alumno(1, "nombreAlumno", "ApellidoAlumno", "99999999", Persona.ENacionalidad.Argentino, Universidad.EClases.Legislacion);
        }

        [TestMethod]
        [ExpectedException(typeof(AlumnoRepetidoException))]
        public void AlumnoRepetidoExcepcionPrueba()
        {
            Universidad universidad;
            Alumno a1;
            Alumno a2;

            universidad = new Universidad();
            a1 = new Alumno(1, "nombreAlumno", "Apellido", "2", Persona.ENacionalidad.Argentino, Universidad.EClases.Legislacion,
                Alumno.EEstadoCuenta.AlDia);
            a2 = new Alumno(1, "nombreAlumno", "Apellido", "2", Persona.ENacionalidad.Argentino, Universidad.EClases.Legislacion,
                Alumno.EEstadoCuenta.AlDia);
            universidad += a1;
            universidad += a2;

        }

        [TestMethod]
        public void ValidarNumeroValidoPrueba()
        {
            Alumno a;
            a = new Alumno(1, "nombreAlumno", "Apellido", "2", Persona.ENacionalidad.Argentino, Universidad.EClases.Legislacion);
            a.StringToDNI = "4234000";
            Assert.AreEqual(4234000, a.DNI);
        }

        [TestMethod]
        public void ValoresNulosPrueba()
        {
            Alumno a;
            a= new Alumno(55,"nombreAlumno","apellidoAlumno","42340000",Persona.ENacionalidad.Argentino,Universidad.EClases.Programacion);
            Assert.IsNotNull(a.Apellido);
        }

    }
}
