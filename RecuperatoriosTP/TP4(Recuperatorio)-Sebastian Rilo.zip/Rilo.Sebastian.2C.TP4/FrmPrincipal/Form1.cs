﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace FrmPrincipal
{
    public partial class FrmPpal : Form
    {
        private Correo correo;

        /// <summary>
        /// se cargan los componentes y se instancia el correo.
        /// </summary>
        public FrmPpal()
        {
            InitializeComponent();
            correo = new Correo();
        }

        /// <summary>
        /// distribuye cada paquete en las diferentes listas segun su estado.
        /// </summary>
        private void ActualizarEstados()
        {
            listEstadoEntregado.Items.Clear();
            listEstadoEnViaje.Items.Clear();
            listEstadoIngresado.Items.Clear();

            foreach(Paquete p in correo.Paquetes)
            {
                if(p.Estado == EEstado.Ingresado)
                {
                    listEstadoIngresado.Items.Add(p);
                }
                else if(p.Estado == EEstado.EnViaje)
                {
                    listEstadoEnViaje.Items.Add(p);
                }
                else
                {
                    listEstadoEntregado.Items.Add(p);
                }
            }
        }

        /// <summary>
        /// Muestra informacion sobre los paquetes en rtbMostrar y la guarda en un archivo de texto en el escritorio.
        /// </summary>
        /// <typeparam name="T">elemento generico</typeparam>
        /// <param name="elemento"> dato que va a ser descripto </param>
        private void MostrarInformacion<T>(IMostrar<T> elemento)
        {
            if(elemento != null)
            {
                rtbMostrar.Text = elemento.MostrarDatos(elemento);
                try
                {
                    rtbMostrar.Text.Guardar(string.Format(@"{0}\salida.txt",Environment.GetFolderPath(Environment.SpecialFolder.Desktop)));
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Agrega un paquete al correo y comienza su ciclo de vida.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Paquete p = new Paquete(txtDireccion.Text,mtxtTrackingID.Text);
            try
            {
                correo += p;
                p.InformaEstado += paq_InformaEstado;
                ActualizarEstados();  
            }
            catch(TrackingIdRepetidoException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// muestra la informacion de todos los paquetes.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnMostrarTodos_Click(object sender, EventArgs e)
        {
            this.MostrarInformacion<List<Paquete>>((IMostrar<List<Paquete>>)correo);
        }

        /// <summary>
        /// cierra todos los subprocesos antes de cerrar el formulario.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmPpal_FormClosing(object sender, FormClosingEventArgs e)
        {
            correo.FinEntregas();
        }

        /// <summary>
        /// muestra informacion del paquete entregado que se selecciono, 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mostrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MostrarInformacion<Paquete>((IMostrar<Paquete>)listEstadoEntregado.SelectedItem);
        }

        /// <summary>
        /// mediador de evento.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void paq_InformaEstado(object sender, EventArgs e)
        {
            if (this.InvokeRequired)
            {
                Paquete.DelegadoEstado d = new Paquete.DelegadoEstado(paq_InformaEstado);
                this.Invoke(d, new object[] { sender, e });
            }
            else
            {
                ActualizarEstados();
            }
        }
    }
}
