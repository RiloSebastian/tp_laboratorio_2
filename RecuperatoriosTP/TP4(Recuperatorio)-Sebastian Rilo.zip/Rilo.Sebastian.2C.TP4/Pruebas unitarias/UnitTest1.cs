﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace Pruebas_unitarias
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ListaDePaquetesInstanciadaTest()
        {
            Correo correo = new Correo();
            Assert.AreNotEqual(null, correo.Paquetes);
        }

        [TestMethod]
        public void DosPaquetesIgualesTest()
        {
            Exception esperada= null;
            Correo correo = new Correo();
            Paquete p1 = new Paquete("ejemplo1", "mismo valor");
            Paquete p2 = new Paquete("ejemplo2", "mismo valor");
            try
            {
                correo += p1;
                correo += p2;
            }
            catch(TrackingIdRepetidoException e)
            {
                esperada = e;
            }
            Assert.IsNotNull(esperada);
        }
    }
}
