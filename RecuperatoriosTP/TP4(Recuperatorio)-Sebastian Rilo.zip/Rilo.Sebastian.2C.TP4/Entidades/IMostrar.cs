﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public interface IMostrar<T>
    {
        /// <summary>
        /// firma de metodo generico.
        /// </summary>
        /// <param name="elemento">elemento generico</param>
        /// <returns></returns>
        string MostrarDatos(IMostrar<T> elemento);
    }
}
