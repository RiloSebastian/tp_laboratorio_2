﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace Entidades
{
    public static class GuardarString
    {
        /// <summary>
        /// guarda una cadena de texto en un archivo
        /// </summary>
        /// <param name="texto">la cadena que se quiere guardar</param>
        /// <param name="archivo">path de el archivo donde se guarde la cadena</param>
        /// <returns></returns>
        public static bool Guardar(this string texto, string archivo)
        {
            StreamWriter writer = new StreamWriter(archivo, true);
            writer.WriteLine(texto);
            writer.Close();

            return true;
        }
    }
}

