﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Entidades
{
    public class Correo : IMostrar<List<Paquete>>
    {
        private List<Thread> mockPaquetes;
        private List<Paquete> paquetes;

        public List<Paquete> Paquetes
        {
            get
            {
                return paquetes;
            }
            set
            {
                paquetes = value;
            }
        }

        /// <summary>
        /// inicializa listas de hilos y paquetes
        /// </summary>
        public Correo()
        {
            mockPaquetes = new List<Thread>();
            Paquetes = new List<Paquete>();
        }

        /// <summary>
        /// agrega el paquete al correo
        /// </summary>
        /// <param name="c">correo donde se va a agregar el paquete</param>
        /// <param name="p">el paquete</param>
        /// <returns></returns>
        public static Correo operator +(Correo c, Paquete p)
        {
            foreach (Paquete enLista in c.Paquetes)
            {
                if (enLista == p)
                {
                    throw new TrackingIdRepetidoException("este paquete ya se encuentra en el correo");
                }
            }
            c.Paquetes.Add(p);
            try
            {
                Thread mock = new Thread(p.MockCicloDeVida);
                c.mockPaquetes.Add(mock);
                mock.Start();
            }
            catch(Exception e)
            {
                throw new Exception(e.Message);
            }
            return c;
        }

        /// <summary>
        /// cierra todos los hilos
        /// </summary>
        public void FinEntregas()
        {
            foreach (Thread t in this.mockPaquetes)
            {
                if (t.IsAlive)
                {
                    t.Abort();
                }
                
            }
        }

        /// <summary>
        /// muestra datos de cada paquete y su estado
        /// </summary>
        /// <param name="elemento"> lista de paquetes</param>
        /// <returns></returns>
        public string MostrarDatos(IMostrar<List<Paquete>> elemento)
        {
            StringBuilder retorno = new StringBuilder();
            foreach (Paquete p in ((Correo)elemento).Paquetes)
            {
                retorno.AppendLine(string.Format("{0} para {1}({2})", p.TrackingID, p.DireccionEntrega, p.Estado.ToString()));
            }
            return retorno.ToString();
        }
    }
}
