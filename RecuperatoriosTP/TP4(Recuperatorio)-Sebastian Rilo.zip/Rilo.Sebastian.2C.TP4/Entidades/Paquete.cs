﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Entidades
{
    public enum EEstado
    {
        Ingresado,
        EnViaje,
        Entregado
    }

    
    public class Paquete : IMostrar<Paquete>
    {
        private string direccionEntrega;
        private EEstado estado;
        private string trackingID;
        public delegate void DelegadoEstado(object sender, EventArgs e);
        public event DelegadoEstado InformaEstado;

        public string DireccionEntrega
        {
            get
            {
                return direccionEntrega;
            }
            set
            {
                direccionEntrega = value;
            }
        }

        public EEstado Estado
        {
            get
            {
                return estado;
            }
            set
            {
                estado = value;
            }
        }

        public string TrackingID
        {
            get
            {
                return trackingID;
            }
            set
            {
                trackingID = value;
            }
        }

        /// <summary>
        /// asigna valores al paquete y establece su estado como "ingresado".
        /// </summary>
        /// <param name="direccionEntrega">direccion de la entrega</param>
        /// <param name="trackingID">codigo de rastreo</param>
        public Paquete(string direccionEntrega, string trackingID)
        {
            DireccionEntrega = direccionEntrega;
            TrackingID = trackingID;
            Estado = EEstado.Ingresado;
        }

        /// <summary>
        /// si dos paquetes tienen el mismo codigo de rastreo son iguales
        /// </summary>
        /// <param name="p1">paquete 1</param>
        /// <param name="p2">paquete 2</param>
        /// <returns></returns>
        public static bool operator ==(Paquete p1, Paquete p2)
        {
            if (string.Compare(p1.TrackingID, p2.TrackingID) == 0)
            {
                throw new TrackingIdRepetidoException("este id ya se uso");
            }
            return false;
        }

        /// <summary>
        /// si dos paquetes no tienen el mismo codigo de rastreo son distintos
        /// </summary>
        /// <param name="p1">paquete 1</param>
        /// <param name="p2">paquete 2</param>
        /// <returns></returns>
        public static bool operator !=(Paquete p1, Paquete p2)
        {
            return !(p1 == p2);
        }

        /// <summary>
        /// cambia el estado del paquete cada 4 segundos hasta llegar a "entregado"
        /// </summary>
        public void MockCicloDeVida()
        {
            while (this.Estado != EEstado.Entregado)
            {
                Thread.Sleep(4000);
                Estado += 1;
                InformaEstado.Invoke(this,null);
            }
            
            try
            {
                PaqueteDAO.Insertar(this);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        /// <summary>
        /// muestra informacion de un paquete especifico, sin revelar su estado
        /// </summary>
        /// <param name="elemento">el paquete</param>
        /// <returns></returns>
        public string MostrarDatos(IMostrar<Paquete> elemento)
        {
            return String.Format("{0} para {1}", ((Paquete)elemento).TrackingID, ((Paquete)elemento).DireccionEntrega);
        }

        /// <summary>
        /// reutiliza el metodo MostrarDatos
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return MostrarDatos(this);
        }
    }
}

