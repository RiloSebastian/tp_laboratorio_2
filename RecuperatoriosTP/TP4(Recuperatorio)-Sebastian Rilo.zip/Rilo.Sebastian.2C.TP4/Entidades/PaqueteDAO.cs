﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Entidades
{
    public static class PaqueteDAO
    {
        private static SqlConnection connection;
        private static SqlCommand command;

        /// <summary>
        /// establece una coneccion con la base de datos
        /// </summary>
        static PaqueteDAO()
        {
            try
            {
                connection = new SqlConnection(@"Data Source =.\SQLEXPRESS; Initial Catalog =correo-sp-2017; Integrated Security = True");
                command = new SqlCommand();
                command.CommandType = System.Data.CommandType.Text;
                command.Connection = connection;
            }
            catch (Exception e)
            {
                throw new Exception("ocurrio un problema con la base de datos", e);
            }
        }

        /// <summary>
        /// inserta un paquete con sus datos en la base de datos
        /// </summary>
        /// <param name="p">el paquete a insertar</param>
        /// <returns></returns>
        public static bool Insertar(Paquete p)
        {
            bool retorno= false;
            command.CommandText = string.Format("INSERT INTO paquetes (direccionEntrega, trackingID, alumno) values('{0}','{1}', 'Sebastian Rilo')",
                p.DireccionEntrega, p.TrackingID);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                retorno = true;
            }
            catch (Exception e)
            {
                throw new Exception("ocurrio un problema con la base de datos",e);
            }
            finally
            {
                connection.Close();
            }
            return retorno;
        }
    }
}
