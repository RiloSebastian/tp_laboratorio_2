﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class TrackingIdRepetidoException : Exception
    {
        /// <summary>
        /// excepcion al repetirse un codigo de rastreo
        /// </summary>
        /// <param name="message">mensaje</param>
        public TrackingIdRepetidoException(string message) : base(message)
        { }

        /// <summary>
        /// sobrecarga del constructor. agrega innerexception
        /// </summary>
        /// <param name="message">mensaje</param>
        /// <param name="e">la excepcion que provoco el lanzamiento de TrackingIdRepetidoException</param>
        public TrackingIdRepetidoException(string message, Exception e) : base(message, e)
        { }
    }
}
